Loaded best params for stage_1A_study from stage_1A.db: Cost = 29.5231 | e_RMS = 0.3326 | u_RMS = 2.0785
Loaded best params for stage_1B_study from stage_1B.db: Cost = 78.0049 | e_RMS = 0.3739 | u_RMS = 3.2464
Loaded best params for stage_3_study from stage_3.db: Cost = 138.1296 | e_RMS = 0.7442 | u_RMS = 3.7040
Loaded best params for stage_4_study from stage_4.db: Cost = 80.8010 | e_RMS = 0.4195 | u_RMS = 3.1780
Loaded best params for stage_2A_study from stage_2A.db: Cost = 83.4071 | e_RMS = 0.5006 | u_RMS = 2.9645
Loaded best params for stage_2B_study from stage_2B.db: Cost = 83.6201 | e_RMS = 0.3963 | u_RMS = 3.3158