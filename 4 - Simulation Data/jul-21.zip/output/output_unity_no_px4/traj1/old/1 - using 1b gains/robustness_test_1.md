=================================================
 DESCRIPTIVE STATISTICS (Non-Normal Distribution)
==================================================
                Median Cost        IQR  Max Cost (Worst)  Min Cost (Best)
RISE             222.322170  37.060767        256.423540       172.095305
SuperTwisting    344.540840  72.242342        428.145641       282.490807
NN_Feedforward   226.942623  48.752272        347.314755       151.005968
INN_Integrated   224.145994  62.679146        593.690083       166.625349

==================================================
 WILCOXON SIGNED-RANK TEST (Alpha = 0.05)
==================================================
INN vs NN Feedforward:
  p-value = 4.7816e-01
  RESULT: No significant difference between INN and NN.

INN vs RISE Baseline:
  p-value = 7.8478e-01

==================================================
 1. NORMALITY CHECKS (Shapiro-Wilk, Alpha = 0.05)
==================================================
[RISE] p-value: 2.5048e-01 -> APPROXIMATELY NORMAL
[SuperTwisting] p-value: 1.7418e-01 -> APPROXIMATELY NORMAL
[NN_Feedforward] p-value: 8.3738e-02 -> APPROXIMATELY NORMAL
[INN_Integrated] p-value: 9.5968e-06 -> NOT NORMAL (Skewed)

==================================================
 2. STATISTICAL SIGNIFICANCE (Alpha = 0.05)
==================================================

INN_Integrated vs NN_Feedforward:
  Test Used: Wilcoxon Signed-Rank Test (Pairwise Difference Normality p = 1.9452e-04)
  Conclusion: INN_Integrated was better than NN_Feedforward, but it was NOT statistically significant (p = 4.7816e-01).

INN_Integrated vs RISE:
  Test Used: Wilcoxon Signed-Rank Test (Pairwise Difference Normality p = 2.2839e-05)
  Conclusion: INN_Integrated was worse than RISE, but it was NOT statistically significant (p = 7.8478e-01).

INN_Integrated vs SuperTwisting:
  Test Used: Wilcoxon Signed-Rank Test (Pairwise Difference Normality p = 2.4563e-03)
  Conclusion: INN_Integrated was better than SuperTwisting, and this WAS statistically significant (p = 2.9278e-04).
==========================================
 Robustness Evaluation Complete.
==========================================