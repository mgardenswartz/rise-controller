==================================================
 DESCRIPTIVE STATISTICS (Non-Normal Distribution)
==================================================
                Median Cost         IQR  Max Cost (Worst)  Min Cost (Best)
RISE             226.288195   39.996508        269.090309       188.656016
SuperTwisting    345.069182   76.952541        450.698569       270.473694
NN_Feedforward   248.648159   54.605653        381.684010       193.710371
INN_Integrated   301.246104  114.163495        532.226271       209.857503

==================================================
 WILCOXON SIGNED-RANK TEST (Alpha = 0.05)
==================================================
INN vs NN Feedforward:
  p-value = 9.9585e-01
  RESULT: No significant difference between INN and NN.

INN vs RISE Baseline:
  p-value = 9.9998e-01

==================================================
 1. NORMALITY CHECKS (Shapiro-Wilk, Alpha = 0.05)
==================================================
[RISE] p-value: 2.3162e-01 -> APPROXIMATELY NORMAL
[SuperTwisting] p-value: 3.9689e-01 -> APPROXIMATELY NORMAL
[NN_Feedforward] p-value: 1.7116e-01 -> APPROXIMATELY NORMAL
[INN_Integrated] p-value: 1.9198e-01 -> APPROXIMATELY NORMAL

==================================================
 2. STATISTICAL SIGNIFICANCE (Alpha = 0.05)
==================================================

INN_Integrated vs NN_Feedforward:
  Test Used: Wilcoxon Signed-Rank Test (Pairwise Difference Normality p = 4.8861e-02)
  Conclusion: INN_Integrated was worse than NN_Feedforward, but it was NOT statistically significant (p = 9.9585e-01).

INN_Integrated vs RISE:
  Test Used: Paired t-test (Pairwise Difference Normality p = 5.0177e-01)
  Conclusion: INN_Integrated was worse than RISE, but it was NOT statistically significant (p = 9.9998e-01).

INN_Integrated vs SuperTwisting:
  Test Used: Paired t-test (Pairwise Difference Normality p = 6.1784e-02)
  Conclusion: INN_Integrated was better than SuperTwisting, but it was NOT statistically significant (p = 1.4550e-01).
==========================================
 Robustness Evaluation Complete.
==========================================