==================================================
 DESCRIPTIVE STATISTICS - e_RMS
==================================================
                Median e_RMS       IQR  Max e_RMS (Worst)  Min e_RMS (Best)
RISE                0.689675  0.125136           0.856406          0.637494
SuperTwisting       0.894536  0.072107           1.070732          0.833916
NN_Feedforward      0.714665  0.115359           0.870785          0.650620
INN_Integrated      0.703225  0.118794           0.870344          0.649168

==================================================
 1. NORMALITY CHECKS (Shapiro-Wilk) - e_RMS
==================================================
[RISE_e_RMS] p-value: 1.9812e-02 -> NOT NORMAL (Skewed)
[SuperTwisting_e_RMS] p-value: 8.2259e-02 -> APPROXIMATELY NORMAL
[NN_Feedforward_e_RMS] p-value: 6.5086e-02 -> APPROXIMATELY NORMAL
[INN_Integrated_e_RMS] p-value: 2.2253e-02 -> NOT NORMAL (Skewed)

==================================================
 2. STATISTICAL SIGNIFICANCE - e_RMS
==================================================

INN_Integrated_e_RMS vs NN_Feedforward_e_RMS:
  Test Used: Paired t-test (Pairwise Difference Normality p = 8.7436e-01)
  Conclusion: INN_Integrated_e_RMS was better than NN_Feedforward_e_RMS, but it was NOT statistically significant (p = 1.5389e-01).

INN_Integrated_e_RMS vs RISE_e_RMS:
  Test Used: Wilcoxon Signed-Rank Test (Pairwise Difference Normality p = 1.6088e-02)
  Conclusion: INN_Integrated_e_RMS was worse than RISE_e_RMS, but it was NOT statistically significant (p = 9.9984e-01).

INN_Integrated_e_RMS vs SuperTwisting_e_RMS:
  Test Used: Paired t-test (Pairwise Difference Normality p = 5.6781e-02)
  Conclusion: INN_Integrated_e_RMS was better than SuperTwisting_e_RMS, and this WAS statistically significant (p = 2.0838e-12).

==================================================
 DESCRIPTIVE STATISTICS - u_RMS
==================================================
                Median u_RMS       IQR  Max u_RMS (Worst)  Min u_RMS (Best)
RISE                4.629976  0.027442           4.665010          4.586995
SuperTwisting       4.743946  0.093655           5.293727          4.647954
NN_Feedforward      4.647821  0.027303           4.701580          4.609327
INN_Integrated      4.686449  0.044993           4.758716          4.639630

==================================================
 1. NORMALITY CHECKS (Shapiro-Wilk) - u_RMS
==================================================
[RISE_u_RMS] p-value: 8.5788e-01 -> APPROXIMATELY NORMAL
[SuperTwisting_u_RMS] p-value: 8.2209e-06 -> NOT NORMAL (Skewed)
[NN_Feedforward_u_RMS] p-value: 3.2587e-01 -> APPROXIMATELY NORMAL
[INN_Integrated_u_RMS] p-value: 8.4866e-01 -> APPROXIMATELY NORMAL

==================================================
 2. STATISTICAL SIGNIFICANCE - u_RMS
==================================================

INN_Integrated_u_RMS vs NN_Feedforward_u_RMS:
  Test Used: Paired t-test (Pairwise Difference Normality p = 9.3743e-02)
  Conclusion: INN_Integrated_u_RMS was worse than NN_Feedforward_u_RMS, but it was NOT statistically significant (p = 1.0000e+00).

INN_Integrated_u_RMS vs RISE_u_RMS:
  Test Used: Paired t-test (Pairwise Difference Normality p = 3.5613e-01)
  Conclusion: INN_Integrated_u_RMS was worse than RISE_u_RMS, but it was NOT statistically significant (p = 1.0000e+00).

INN_Integrated_u_RMS vs SuperTwisting_u_RMS:
  Test Used: Wilcoxon Signed-Rank Test (Pairwise Difference Normality p = 6.7580e-05)
  Conclusion: INN_Integrated_u_RMS was better than SuperTwisting_u_RMS, and this WAS statistically significant (p = 1.8272e-03).

==================================================
 DESCRIPTIVE STATISTICS - Cost
==================================================
                Median Cost        IQR  Max Cost (Worst)  Min Cost (Best)
RISE             220.848895   5.710337        228.038630       213.369906
SuperTwisting    298.432104  18.380850        453.419751       274.975353
NN_Feedforward   224.124945   9.147539        244.222040       215.566153
INN_Integrated   231.698559   8.627683        241.802891       222.345536

==================================================
 1. NORMALITY CHECKS (Shapiro-Wilk) - Cost
==================================================
[RISE_Cost] p-value: 6.6425e-01 -> APPROXIMATELY NORMAL
[SuperTwisting_Cost] p-value: 1.6284e-06 -> NOT NORMAL (Skewed)
[NN_Feedforward_Cost] p-value: 1.4120e-01 -> APPROXIMATELY NORMAL
[INN_Integrated_Cost] p-value: 8.7723e-01 -> APPROXIMATELY NORMAL

==================================================
 2. STATISTICAL SIGNIFICANCE - Cost
==================================================

INN_Integrated_Cost vs NN_Feedforward_Cost:
  Test Used: Wilcoxon Signed-Rank Test (Pairwise Difference Normality p = 3.3054e-02)
  Conclusion: INN_Integrated_Cost was worse than NN_Feedforward_Cost, but it was NOT statistically significant (p = 9.9884e-01).

INN_Integrated_Cost vs RISE_Cost:
  Test Used: Paired t-test (Pairwise Difference Normality p = 7.4245e-01)
  Conclusion: INN_Integrated_Cost was worse than RISE_Cost, but it was NOT statistically significant (p = 1.0000e+00).

INN_Integrated_Cost vs SuperTwisting_Cost:
  Test Used: Wilcoxon Signed-Rank Test (Pairwise Difference Normality p = 3.1237e-06)
  Conclusion: INN_Integrated_Cost was better than SuperTwisting_Cost, and this WAS statistically significant (p = 9.5367e-07).
==========================================
 Robustness Evaluation Complete.
==========================================