Loaded best params for stage_1A_study from stage_1A.db: Cost = 184.5246 | e_RMS = 0.6409 | u_RMS = 3.6248
Loaded best params for stage_1B_study from stage_1B.db: Cost = 362.4286 | e_RMS = 0.7649 | u_RMS = 4.3958
Loaded best params for stage_3_study from stage_3.db: Cost = 508.1522 | e_RMS = 0.9510 | u_RMS = 5.7298
Loaded best params for stage_4_study from stage_4.db: Cost = 393.0285 | e_RMS = 0.9029 | u_RMS = 3.9990
Loaded best params for stage_2A_study from stage_2A.db: Cost = 308.6984 | e_RMS = 0.7723 | u_RMS = 4.0956
Loaded best params for stage_2B_study from stage_2B.db: Cost = 369.3661 | e_RMS = 0.9249 | u_RMS = 4.2540

[*] Extracted best gains and saved to 'output/traj1/best_gains.yaml'