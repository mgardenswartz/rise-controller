==================================================
 DESCRIPTIVE STATISTICS - e_RMS
==================================================
                Median e_RMS       IQR  Max e_RMS (Worst)  Min e_RMS (Best)
RISE                0.309810  0.056354           0.429222          0.248413
SuperTwisting       0.557057  0.064821           0.726208          0.432578
PID                 0.354737  0.051982           0.454852          0.301125
NN_Feedforward      0.668184  0.158664           0.755388          0.478341
INN_Integrated      0.344706  0.088126           0.470567          0.220478

==================================================
 1. NORMALITY CHECKS (Shapiro-Wilk) - e_RMS
==================================================
[RISE_e_RMS] p-value: 4.8636e-01 -> APPROXIMATELY NORMAL
[SuperTwisting_e_RMS] p-value: 4.4450e-01 -> APPROXIMATELY NORMAL
[PID_e_RMS] p-value: 1.4552e-01 -> APPROXIMATELY NORMAL
[NN_Feedforward_e_RMS] p-value: 3.1135e-02 -> NOT NORMAL (Skewed)
[INN_Integrated_e_RMS] p-value: 6.6025e-01 -> APPROXIMATELY NORMAL

==================================================
 2. STATISTICAL SIGNIFICANCE - e_RMS
==================================================

INN_Integrated_e_RMS vs NN_Feedforward_e_RMS:
  Test Used: Paired t-test (Pairwise Difference Normality p = 4.0284e-01)
  Conclusion: INN_Integrated_e_RMS was better than NN_Feedforward_e_RMS, and this WAS statistically significant (p = 5.8510e-10).

INN_Integrated_e_RMS vs RISE_e_RMS:
  Test Used: Wilcoxon Signed-Rank Test (Pairwise Difference Normality p = 1.4694e-02)
  Conclusion: INN_Integrated_e_RMS was worse than RISE_e_RMS, but it was NOT statistically significant (p = 9.9141e-01).

INN_Integrated_e_RMS vs SuperTwisting_e_RMS:
  Test Used: Paired t-test (Pairwise Difference Normality p = 7.7769e-01)
  Conclusion: INN_Integrated_e_RMS was better than SuperTwisting_e_RMS, and this WAS statistically significant (p = 4.3779e-10).

INN_Integrated_e_RMS vs PID_e_RMS:
  Test Used: Wilcoxon Signed-Rank Test (Pairwise Difference Normality p = 4.0390e-02)
  Conclusion: INN_Integrated_e_RMS was better than PID_e_RMS, and this WAS statistically significant (p = 3.4790e-02).

==================================================
 DESCRIPTIVE STATISTICS - u_RMS
==================================================
                Median u_RMS       IQR  Max u_RMS (Worst)  Min u_RMS (Best)
RISE                3.225476  0.044614           3.262877          3.160452
SuperTwisting       3.652985  0.098969           3.745859          3.543024
PID                 3.129432  0.069212           3.193930          3.048201
NN_Feedforward      2.815358  0.181373           3.002818          2.688298
INN_Integrated      3.467436  0.040237           3.629202          3.398109

==================================================
 1. NORMALITY CHECKS (Shapiro-Wilk) - u_RMS
==================================================
[RISE_u_RMS] p-value: 7.9696e-02 -> APPROXIMATELY NORMAL
[SuperTwisting_u_RMS] p-value: 2.4499e-01 -> APPROXIMATELY NORMAL
[PID_u_RMS] p-value: 6.1316e-01 -> APPROXIMATELY NORMAL
[NN_Feedforward_u_RMS] p-value: 9.4572e-02 -> APPROXIMATELY NORMAL
[INN_Integrated_u_RMS] p-value: 8.1760e-03 -> NOT NORMAL (Skewed)

==================================================
 2. STATISTICAL SIGNIFICANCE - u_RMS
==================================================

INN_Integrated_u_RMS vs NN_Feedforward_u_RMS:
  Test Used: Paired t-test (Pairwise Difference Normality p = 5.1638e-01)
  Conclusion: INN_Integrated_u_RMS was worse than NN_Feedforward_u_RMS, but it was NOT statistically significant (p = 1.0000e+00).

INN_Integrated_u_RMS vs RISE_u_RMS:
  Test Used: Wilcoxon Signed-Rank Test (Pairwise Difference Normality p = 1.2133e-02)
  Conclusion: INN_Integrated_u_RMS was worse than RISE_u_RMS, but it was NOT statistically significant (p = 1.0000e+00).

INN_Integrated_u_RMS vs SuperTwisting_u_RMS:
  Test Used: Paired t-test (Pairwise Difference Normality p = 2.8473e-01)
  Conclusion: INN_Integrated_u_RMS was better than SuperTwisting_u_RMS, and this WAS statistically significant (p = 4.4248e-08).

INN_Integrated_u_RMS vs PID_u_RMS:
  Test Used: Wilcoxon Signed-Rank Test (Pairwise Difference Normality p = 4.2691e-02)
  Conclusion: INN_Integrated_u_RMS was worse than PID_u_RMS, but it was NOT statistically significant (p = 1.0000e+00).

==================================================
 DESCRIPTIVE STATISTICS - Cost
==================================================
                Median Cost         IQR  Max Cost (Worst)  Min Cost (Best)
RISE              76.549797    2.126886         78.821568        72.479659
SuperTwisting    122.676512   11.555642        139.151964       107.414988
PID               78.297727    3.291519         82.252822        73.923617
NN_Feedforward   170.425162  101.542103        253.377040        83.609742
INN_Integrated    85.704876    4.433693        106.102548        79.343591

==================================================
 1. NORMALITY CHECKS (Shapiro-Wilk) - Cost
==================================================
[RISE_Cost] p-value: 3.0488e-01 -> APPROXIMATELY NORMAL
[SuperTwisting_Cost] p-value: 4.3598e-01 -> APPROXIMATELY NORMAL
[PID_Cost] p-value: 8.2252e-01 -> APPROXIMATELY NORMAL
[NN_Feedforward_Cost] p-value: 2.4027e-02 -> NOT NORMAL (Skewed)
[INN_Integrated_Cost] p-value: 9.7898e-04 -> NOT NORMAL (Skewed)

==================================================
 2. STATISTICAL SIGNIFICANCE - Cost
==================================================

INN_Integrated_Cost vs NN_Feedforward_Cost:
  Test Used: Wilcoxon Signed-Rank Test (Pairwise Difference Normality p = 4.3203e-02)
  Conclusion: INN_Integrated_Cost was better than NN_Feedforward_Cost, and this WAS statistically significant (p = 9.5367e-06).

INN_Integrated_Cost vs RISE_Cost:
  Test Used: Wilcoxon Signed-Rank Test (Pairwise Difference Normality p = 9.8439e-05)
  Conclusion: INN_Integrated_Cost was worse than RISE_Cost, but it was NOT statistically significant (p = 1.0000e+00).

INN_Integrated_Cost vs SuperTwisting_Cost:
  Test Used: Paired t-test (Pairwise Difference Normality p = 3.7223e-01)
  Conclusion: INN_Integrated_Cost was better than SuperTwisting_Cost, and this WAS statistically significant (p = 6.6487e-11).

INN_Integrated_Cost vs PID_Cost:
  Test Used: Wilcoxon Signed-Rank Test (Pairwise Difference Normality p = 1.4350e-04)
  Conclusion: INN_Integrated_Cost was worse than PID_Cost, but it was NOT statistically significant (p = 1.0000e+00).
