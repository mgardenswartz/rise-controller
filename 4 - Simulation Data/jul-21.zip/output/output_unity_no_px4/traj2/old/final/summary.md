Loaded best params for stage_1A_study from stage_1A.db: Cost = 228.2652 | e_RMS = 0.8824 | u_RMS = 3.7413
Loaded best params for stage_1B_study from stage_1B.db: Cost = 203.7619 | e_RMS = 0.6452 | u_RMS = 3.8844
Loaded best params for stage_3_study from stage_3.db: Cost = 338.2708 | e_RMS = 0.8723 | u_RMS = 3.9235
Loaded best params for stage_4_study from stage_4.db: Cost = 374.4913 | e_RMS = 0.8006 | u_RMS = 4.6985
Loaded best params for stage_2A_study from stage_2A.db: Cost = 187.2264 | e_RMS = 0.6253 | u_RMS = 3.7529
Loaded best params for stage_2B_study from stage_2B.db: Cost = 222.3099 | e_RMS = 0.6649 | u_RMS = 3.8975

[*] Extracted best gains and saved to 'output/traj2/best_gains.yaml'